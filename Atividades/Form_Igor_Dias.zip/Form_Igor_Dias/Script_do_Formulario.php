<?php
    $usuario = $post['nome']
    $msn = "Parabéns Você está inscrito no curso".$usuario;  
    echo $msn;

?>